$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("OrangeHRM_AddMultiJobVacancy.feature");
formatter.feature({
  "line": 2,
  "name": "Creating multiple vacancies",
  "description": "",
  "id": "creating-multiple-vacancies",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@OrangeHRM"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": "Creating multiple vacancies using data from an external excel spreadsheet",
  "description": "",
  "id": "creating-multiple-vacancies;creating-multiple-vacancies-using-data-from-an-external-excel-spreadsheet",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 6,
  "name": "User is on OrangeHRMUrl Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "User enters HRM UserNames and Passwords",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Navigate to the Recruitment page and Click on the Vacancies",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Click on the Add button to navigate to the Add Job Vacancy form",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Fill out the following Details \"\u003cJobTitle\u003e\" \"\u003cVacanyName\u003e\" \"\u003cHiringManger\u003e\" \"\u003cNoOfPosition\u003e\" and \"\u003cDescription\u003e\" details",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Click the Save button to save the vacancy",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "Verify that the vacancy was created",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "Close the HRMbrowser",
  "keyword": "Then "
});
formatter.examples({
  "line": 15,
  "name": "",
  "description": "",
  "id": "creating-multiple-vacancies;creating-multiple-vacancies-using-data-from-an-external-excel-spreadsheet;",
  "rows": [
    {
      "cells": [
        "JobTitle",
        "VacanyName",
        "HiringManger",
        "NoOfPosition",
        "Description"
      ],
      "line": 16,
      "id": "creating-multiple-vacancies;creating-multiple-vacancies-using-data-from-an-external-excel-spreadsheet;;1"
    },
    {
      "cells": [
        "Android Developer",
        "Developer vacancy4",
        "Test Tester",
        "10",
        "Android description"
      ],
      "line": 17,
      "id": "creating-multiple-vacancies;creating-multiple-vacancies-using-data-from-an-external-excel-spreadsheet;;2"
    },
    {
      "cells": [
        "Android Developer",
        "Developer vacancy5",
        "Test Tester",
        "15",
        "Android description"
      ],
      "line": 18,
      "id": "creating-multiple-vacancies;creating-multiple-vacancies-using-data-from-an-external-excel-spreadsheet;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 17,
  "name": "Creating multiple vacancies using data from an external excel spreadsheet",
  "description": "",
  "id": "creating-multiple-vacancies;creating-multiple-vacancies-using-data-from-an-external-excel-spreadsheet;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@OrangeHRM"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "User is on OrangeHRMUrl Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "User enters HRM UserNames and Passwords",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Navigate to the Recruitment page and Click on the Vacancies",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Click on the Add button to navigate to the Add Job Vacancy form",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Fill out the following Details \"Android Developer\" \"Developer vacancy4\" \"Test Tester\" \"10\" and \"Android description\" details",
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4
  ],
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Click the Save button to save the vacancy",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "Verify that the vacancy was created",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "Close the HRMbrowser",
  "keyword": "Then "
});
formatter.match({
  "location": "OrangeHRMSteps.user_is_on_OrangeHRMUrl_Login_Page()"
});
formatter.result({
  "duration": 10898758100,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.user_enters_HRM_UserNames_and_Passwords()"
});
formatter.result({
  "duration": 1776785600,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.navigate_to_the_Recruitment_page()"
});
formatter.result({
  "duration": 6086080100,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.click_on_the_Add_button_to_navigate_to_the_Add_Job_Vacancy_form()"
});
formatter.result({
  "duration": 6545343000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Android Developer",
      "offset": 32
    },
    {
      "val": "Developer vacancy4",
      "offset": 52
    },
    {
      "val": "Test Tester",
      "offset": 73
    },
    {
      "val": "10",
      "offset": 87
    },
    {
      "val": "Android description",
      "offset": 96
    }
  ],
  "location": "OrangeHRMSteps.fill_out_the_following_Details_and_details(String,String,String,String,String)"
});
formatter.result({
  "duration": 951690700,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.click_the_Save_button_to_save_the_vacancy()"
});
formatter.result({
  "duration": 861165400,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.verify_that_the_vacancy_was_created()"
});
formatter.result({
  "duration": 104577000,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.close_the_browser()"
});
formatter.result({
  "duration": 2168612000,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Creating multiple vacancies using data from an external excel spreadsheet",
  "description": "",
  "id": "creating-multiple-vacancies;creating-multiple-vacancies-using-data-from-an-external-excel-spreadsheet;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@OrangeHRM"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "User is on OrangeHRMUrl Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "User enters HRM UserNames and Passwords",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Navigate to the Recruitment page and Click on the Vacancies",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Click on the Add button to navigate to the Add Job Vacancy form",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Fill out the following Details \"Android Developer\" \"Developer vacancy5\" \"Test Tester\" \"15\" and \"Android description\" details",
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4
  ],
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Click the Save button to save the vacancy",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "Verify that the vacancy was created",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "Close the HRMbrowser",
  "keyword": "Then "
});
formatter.match({
  "location": "OrangeHRMSteps.user_is_on_OrangeHRMUrl_Login_Page()"
});
formatter.result({
  "duration": 7034673500,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.user_enters_HRM_UserNames_and_Passwords()"
});
formatter.result({
  "duration": 1686544500,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.navigate_to_the_Recruitment_page()"
});
formatter.result({
  "duration": 6060109900,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.click_on_the_Add_button_to_navigate_to_the_Add_Job_Vacancy_form()"
});
formatter.result({
  "duration": 6746081500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Android Developer",
      "offset": 32
    },
    {
      "val": "Developer vacancy5",
      "offset": 52
    },
    {
      "val": "Test Tester",
      "offset": 73
    },
    {
      "val": "15",
      "offset": 87
    },
    {
      "val": "Android description",
      "offset": 96
    }
  ],
  "location": "OrangeHRMSteps.fill_out_the_following_Details_and_details(String,String,String,String,String)"
});
formatter.result({
  "duration": 753992200,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.click_the_Save_button_to_save_the_vacancy()"
});
formatter.result({
  "duration": 1153066800,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.verify_that_the_vacancy_was_created()"
});
formatter.result({
  "duration": 126924500,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.close_the_browser()"
});
formatter.result({
  "duration": 2532939900,
  "status": "passed"
});
formatter.uri("OrangeHRM_AddMultipleEmployees.feature");
formatter.feature({
  "line": 2,
  "name": "Add multiple employees",
  "description": "",
  "id": "add-multiple-employees",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@OrangeHRM"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": "Add multiple employees using an the examples table",
  "description": "",
  "id": "add-multiple-employees;add-multiple-employees-using-an-the-examples-table",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 6,
  "name": "User is on OrangeHRMUrl Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "User enters HRM UserNames and Passwords",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Find the PIM option in the menu and click it",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Click the Add button to add a new Employee",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Make sure the Create Login Details checkbox is checked",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Fill in the required fields using the \"\u003cFirstname\u003e\" \"\u003cLastName\u003e\" and \"\u003cEmployeeID\u003e\" data from the Examples table",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "Enter \"\u003cUserName\u003e\" and \"\u003cPassword\u003e\" to create the login",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "Click Save",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "Verify that the employees have been created.",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "Close the HRMbrowser",
  "keyword": "Then "
});
formatter.examples({
  "line": 17,
  "name": "",
  "description": "",
  "id": "add-multiple-employees;add-multiple-employees-using-an-the-examples-table;",
  "rows": [
    {
      "cells": [
        "Firstname",
        "LastName",
        "EmployeeID",
        "UserName",
        "Password"
      ],
      "line": 18,
      "id": "add-multiple-employees;add-multiple-employees-using-an-the-examples-table;;1"
    },
    {
      "cells": [
        "mathura6",
        "ganesh2",
        "09880",
        "mathura6ganesh",
        "Mathura1@123"
      ],
      "line": 19,
      "id": "add-multiple-employees;add-multiple-employees-using-an-the-examples-table;;2"
    },
    {
      "cells": [
        "veera2",
        "ganesh2",
        "09861",
        "veera2ganesh",
        "Mathura1@123"
      ],
      "line": 20,
      "id": "add-multiple-employees;add-multiple-employees-using-an-the-examples-table;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 19,
  "name": "Add multiple employees using an the examples table",
  "description": "",
  "id": "add-multiple-employees;add-multiple-employees-using-an-the-examples-table;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@OrangeHRM"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "User is on OrangeHRMUrl Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "User enters HRM UserNames and Passwords",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Find the PIM option in the menu and click it",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Click the Add button to add a new Employee",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Make sure the Create Login Details checkbox is checked",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Fill in the required fields using the \"mathura6\" \"ganesh2\" and \"09880\" data from the Examples table",
  "matchedColumns": [
    0,
    1,
    2
  ],
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "Enter \"mathura6ganesh\" and \"Mathura1@123\" to create the login",
  "matchedColumns": [
    3,
    4
  ],
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "Click Save",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "Verify that the employees have been created.",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "Close the HRMbrowser",
  "keyword": "Then "
});
formatter.match({
  "location": "OrangeHRMSteps.user_is_on_OrangeHRMUrl_Login_Page()"
});
formatter.result({
  "duration": 9056396800,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.user_enters_HRM_UserNames_and_Passwords()"
});
formatter.result({
  "duration": 1856941800,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.find_the_PIM_option_in_the_menu_and_click_it()"
});
formatter.result({
  "duration": 4039450700,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.click_the_Add_button_to_add_a_new_Employee()"
});
formatter.result({
  "duration": 1901467500,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.make_sure_the_Create_Login_Details_checkbox_is_checked()"
});
formatter.result({
  "duration": 375818800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "mathura6",
      "offset": 39
    },
    {
      "val": "ganesh2",
      "offset": 50
    },
    {
      "val": "09880",
      "offset": 64
    }
  ],
  "location": "OrangeHRMSteps.fill_in_the_required_fields_using_the_data_from_the_Examples_table(String,String,String)"
});
formatter.result({
  "duration": 12624156100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "mathura6ganesh",
      "offset": 7
    },
    {
      "val": "Mathura1@123",
      "offset": 28
    }
  ],
  "location": "OrangeHRMSteps.enter_and_to_create_the_login(String,String)"
});
formatter.result({
  "duration": 356394800,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.click_Save()"
});
formatter.result({
  "duration": 2345752000,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.verify_that_the_employees_have_been_created()"
});
formatter.result({
  "duration": 197590400,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.close_the_browser()"
});
formatter.result({
  "duration": 2806081400,
  "status": "passed"
});
formatter.scenario({
  "line": 20,
  "name": "Add multiple employees using an the examples table",
  "description": "",
  "id": "add-multiple-employees;add-multiple-employees-using-an-the-examples-table;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@OrangeHRM"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "User is on OrangeHRMUrl Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "User enters HRM UserNames and Passwords",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Find the PIM option in the menu and click it",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Click the Add button to add a new Employee",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Make sure the Create Login Details checkbox is checked",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Fill in the required fields using the \"veera2\" \"ganesh2\" and \"09861\" data from the Examples table",
  "matchedColumns": [
    0,
    1,
    2
  ],
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "Enter \"veera2ganesh\" and \"Mathura1@123\" to create the login",
  "matchedColumns": [
    3,
    4
  ],
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "Click Save",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "Verify that the employees have been created.",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "Close the HRMbrowser",
  "keyword": "Then "
});
formatter.match({
  "location": "OrangeHRMSteps.user_is_on_OrangeHRMUrl_Login_Page()"
});
formatter.result({
  "duration": 7445791600,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.user_enters_HRM_UserNames_and_Passwords()"
});
formatter.result({
  "duration": 1629496500,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.find_the_PIM_option_in_the_menu_and_click_it()"
});
formatter.result({
  "duration": 4029786900,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.click_the_Add_button_to_add_a_new_Employee()"
});
formatter.result({
  "duration": 1352624000,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.make_sure_the_Create_Login_Details_checkbox_is_checked()"
});
formatter.result({
  "duration": 372221700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "veera2",
      "offset": 39
    },
    {
      "val": "ganesh2",
      "offset": 48
    },
    {
      "val": "09861",
      "offset": 62
    }
  ],
  "location": "OrangeHRMSteps.fill_in_the_required_fields_using_the_data_from_the_Examples_table(String,String,String)"
});
formatter.result({
  "duration": 12271890200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "veera2ganesh",
      "offset": 7
    },
    {
      "val": "Mathura1@123",
      "offset": 26
    }
  ],
  "location": "OrangeHRMSteps.enter_and_to_create_the_login(String,String)"
});
formatter.result({
  "duration": 254984000,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.click_Save()"
});
formatter.result({
  "duration": 1508581900,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.verify_that_the_employees_have_been_created()"
});
formatter.result({
  "duration": 115573000,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.close_the_browser()"
});
formatter.result({
  "duration": 1777199700,
  "status": "passed"
});
formatter.uri("OrangeHRM_AddingCandidate.feature");
formatter.feature({
  "line": 2,
  "name": "Adding a candidate for recruitment",
  "description": "",
  "id": "adding-a-candidate-for-recruitment",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@OrangeHRM"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "Add information about a candidate for recruitment",
  "description": "",
  "id": "adding-a-candidate-for-recruitment;add-information-about-a-candidate-for-recruitment",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "User is on OrangeHRMUrl Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "User enters HRM UserNames and Passwords",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Navigate to the Recruitment page and click on the Add button",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Fill in the details of the candidate",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Upload a resume to the form",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Click Save",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "Navigate back to the Recruitments page to confirm candidate entry",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "Close the HRMbrowser",
  "keyword": "Then "
});
formatter.match({
  "location": "OrangeHRMSteps.user_is_on_OrangeHRMUrl_Login_Page()"
});
formatter.result({
  "duration": 7015630800,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.user_enters_HRM_UserNames_and_Passwords()"
});
formatter.result({
  "duration": 1675649800,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.navigate_to_the_Recruitment_page_and_click_on_the_Add_button()"
});
formatter.result({
  "duration": 5962202500,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.fill_in_the_details_of_the_candidate()"
});
formatter.result({
  "duration": 652857000,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.upload_a_resume_to_the_form()"
});
formatter.result({
  "duration": 12062220600,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.click_Save()"
});
formatter.result({
  "duration": 858593600,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.navigate_back_to_the_Recruitments_page_to_confirm_candidate_entry()"
});
formatter.result({
  "duration": 5916361500,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.close_the_browser()"
});
formatter.result({
  "duration": 1992617100,
  "status": "passed"
});
formatter.uri("OrangeHRM_CreatingJobVacancy.feature");
formatter.feature({
  "line": 2,
  "name": "Creating a job vacancy",
  "description": "",
  "id": "creating-a-job-vacancy",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@OrangeHRM"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "Adding a candidate for recruitment",
  "description": "",
  "id": "creating-a-job-vacancy;adding-a-candidate-for-recruitment",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "User is on OrangeHRMUrl Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "User enters HRM UserNames and Passwords",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Navigate to the Recruitment page and Click on the Vacancies",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Click on the Add button to navigate to the Add Job Vacancy form",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Fill out the necessary details",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Click the Save button to save the vacancy",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "Verify that the vacancy was created",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "Close the HRMbrowser",
  "keyword": "Then "
});
formatter.match({
  "location": "OrangeHRMSteps.user_is_on_OrangeHRMUrl_Login_Page()"
});
formatter.result({
  "duration": 7607466800,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.user_enters_HRM_UserNames_and_Passwords()"
});
formatter.result({
  "duration": 1442739100,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.navigate_to_the_Recruitment_page()"
});
formatter.result({
  "duration": 6068815200,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.click_on_the_Add_button_to_navigate_to_the_Add_Job_Vacancy_form()"
});
formatter.result({
  "duration": 6573425800,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.fill_out_the_necessary_details()"
});
formatter.result({
  "duration": 696467100,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.click_the_Save_button_to_save_the_vacancy()"
});
formatter.result({
  "duration": 792685000,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.verify_that_the_vacancy_was_created()"
});
formatter.result({
  "duration": 67374300,
  "status": "passed"
});
formatter.match({
  "location": "OrangeHRMSteps.close_the_browser()"
});
formatter.result({
  "duration": 2358690500,
  "status": "passed"
});
});