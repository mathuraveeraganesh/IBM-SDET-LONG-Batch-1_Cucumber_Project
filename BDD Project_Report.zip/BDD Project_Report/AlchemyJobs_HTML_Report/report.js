$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("AlchemyJobs_CreateNewUser.feature");
formatter.feature({
  "line": 2,
  "name": "Create a new user",
  "description": "",
  "id": "create-a-new-user",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@AlchemyJobs"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "Visit the site�s backend and create a new user",
  "description": "",
  "id": "create-a-new-user;visit-the-site�s-backend-and-create-a-new-user",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "User is on AlchemyUrl Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "User enters UserNames and Passwords",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Locate the left hand menu and click the menu item that says Users",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Locate the Add New button and click it",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Fill in the necessary details",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Click the Add New User button",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "Verify that the user was created",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "Close the AlchemyBrowser",
  "keyword": "Then "
});
formatter.match({
  "location": "AlchemyJobsSteps.user_is_on_AlchemyUrl_Login_Page()"
});
formatter.result({
  "duration": 11007051800,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.user_enters_UserNames_and_Passwords()"
});
formatter.result({
  "duration": 2690647800,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.locate_the_left_hand_menu_and_click_the_menu_item_that_says_Users()"
});
formatter.result({
  "duration": 2167624000,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.locate_the_Add_New_button_and_click_it()"
});
formatter.result({
  "duration": 1484893000,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.fill_in_the_necessary_details()"
});
formatter.result({
  "duration": 868129000,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.click_the_Add_New_User_button()"
});
formatter.result({
  "duration": 5763149800,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.verify_that_the_user_was_created()"
});
formatter.result({
  "duration": 7610439400,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.close_the_AlchemyBrowser()"
});
formatter.result({
  "duration": 2416612000,
  "status": "passed"
});
formatter.uri("AlchemyJobs_MultiPostingJobs.feature");
formatter.feature({
  "line": 2,
  "name": "Using Examples table to post a job",
  "description": "",
  "id": "using-examples-table-to-post-a-job",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@AlchemyJobs"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": "Multiple Job Post",
  "description": "",
  "id": "using-examples-table-to-post-a-job;multiple-job-post",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 6,
  "name": "User is on AlchemyJobUrl Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "Go to Post a Job page",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Enter the Email \"\u003cEmail\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Enter the JobTitle \"\u003cJobTitle\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Enter the JobDescription \"\u003cJobDescription\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Enter the ApplicationUrl \"\u003cApplicationUrl\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "Enter the CompanyName \"\u003cCompanyName\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "Click submit",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "Go to the Jobs page",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "Confirm job listing is shown on page.",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "Close the AlchemyBrowser",
  "keyword": "Then "
});
formatter.examples({
  "line": 18,
  "name": "",
  "description": "",
  "id": "using-examples-table-to-post-a-job;multiple-job-post;",
  "rows": [
    {
      "cells": [
        "Email",
        "JobTitle",
        "JobDescription",
        "ApplicationUrl",
        "CompanyName"
      ],
      "line": 19,
      "id": "using-examples-table-to-post-a-job;multiple-job-post;;1"
    },
    {
      "cells": [
        "mathura9@gmail.com",
        "Test Title",
        "Test Description",
        "https://alchemy.hguy.co/jobs/post-a-job/",
        "IBM"
      ],
      "line": 20,
      "id": "using-examples-table-to-post-a-job;multiple-job-post;;2"
    },
    {
      "cells": [
        "mathura10@gmail.com",
        "Test Title1",
        "Test Description1",
        "https://alchemy.hguy.co/jobs/post-a-job/",
        "HCL"
      ],
      "line": 21,
      "id": "using-examples-table-to-post-a-job;multiple-job-post;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 20,
  "name": "Multiple Job Post",
  "description": "",
  "id": "using-examples-table-to-post-a-job;multiple-job-post;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@AlchemyJobs"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "User is on AlchemyJobUrl Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "Go to Post a Job page",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Enter the Email \"mathura9@gmail.com\"",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Enter the JobTitle \"Test Title\"",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Enter the JobDescription \"Test Description\"",
  "matchedColumns": [
    2
  ],
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Enter the ApplicationUrl \"https://alchemy.hguy.co/jobs/post-a-job/\"",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "Enter the CompanyName \"IBM\"",
  "matchedColumns": [
    4
  ],
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "Click submit",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "Go to the Jobs page",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "Confirm job listing is shown on page.",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "Close the AlchemyBrowser",
  "keyword": "Then "
});
formatter.match({
  "location": "AlchemyJobsSteps.user_is_on_AlchemyJobUrl_Login_Page()"
});
formatter.result({
  "duration": 6851503300,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.go_to_Post_a_Job_page()"
});
formatter.result({
  "duration": 2176312300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "mathura9@gmail.com",
      "offset": 17
    }
  ],
  "location": "AlchemyJobsSteps.enter_the_Email(String)"
});
formatter.result({
  "duration": 144026400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Test Title",
      "offset": 20
    }
  ],
  "location": "AlchemyJobsSteps.enter_the_JobTitle(String)"
});
formatter.result({
  "duration": 82300100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Test Description",
      "offset": 26
    }
  ],
  "location": "AlchemyJobsSteps.enter_the_JobDescription(String)"
});
formatter.result({
  "duration": 5269430500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "https://alchemy.hguy.co/jobs/post-a-job/",
      "offset": 26
    }
  ],
  "location": "AlchemyJobsSteps.enter_the_ApplicationUrl(String)"
});
formatter.result({
  "duration": 156496000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "IBM",
      "offset": 23
    }
  ],
  "location": "AlchemyJobsSteps.enter_the_CompanyName(String)"
});
formatter.result({
  "duration": 63054200,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.click_submit()"
});
formatter.result({
  "duration": 1835916800,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.go_to_the_Jobs_page()"
});
formatter.result({
  "duration": 4803167100,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.confirm_job_listing_is_shown_on_page()"
});
formatter.result({
  "duration": 5329550300,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.close_the_AlchemyBrowser()"
});
formatter.result({
  "duration": 1834746400,
  "status": "passed"
});
formatter.scenario({
  "line": 21,
  "name": "Multiple Job Post",
  "description": "",
  "id": "using-examples-table-to-post-a-job;multiple-job-post;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@AlchemyJobs"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "User is on AlchemyJobUrl Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "Go to Post a Job page",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Enter the Email \"mathura10@gmail.com\"",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Enter the JobTitle \"Test Title1\"",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Enter the JobDescription \"Test Description1\"",
  "matchedColumns": [
    2
  ],
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Enter the ApplicationUrl \"https://alchemy.hguy.co/jobs/post-a-job/\"",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "Enter the CompanyName \"HCL\"",
  "matchedColumns": [
    4
  ],
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "Click submit",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "Go to the Jobs page",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "Confirm job listing is shown on page.",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "Close the AlchemyBrowser",
  "keyword": "Then "
});
formatter.match({
  "location": "AlchemyJobsSteps.user_is_on_AlchemyJobUrl_Login_Page()"
});
formatter.result({
  "duration": 6798152100,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.go_to_Post_a_Job_page()"
});
formatter.result({
  "duration": 2194376700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "mathura10@gmail.com",
      "offset": 17
    }
  ],
  "location": "AlchemyJobsSteps.enter_the_Email(String)"
});
formatter.result({
  "duration": 117514400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Test Title1",
      "offset": 20
    }
  ],
  "location": "AlchemyJobsSteps.enter_the_JobTitle(String)"
});
formatter.result({
  "duration": 72136000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Test Description1",
      "offset": 26
    }
  ],
  "location": "AlchemyJobsSteps.enter_the_JobDescription(String)"
});
formatter.result({
  "duration": 5222451600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "https://alchemy.hguy.co/jobs/post-a-job/",
      "offset": 26
    }
  ],
  "location": "AlchemyJobsSteps.enter_the_ApplicationUrl(String)"
});
formatter.result({
  "duration": 126190900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "HCL",
      "offset": 23
    }
  ],
  "location": "AlchemyJobsSteps.enter_the_CompanyName(String)"
});
formatter.result({
  "duration": 55107700,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.click_submit()"
});
formatter.result({
  "duration": 2237961900,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.go_to_the_Jobs_page()"
});
formatter.result({
  "duration": 4747670000,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.confirm_job_listing_is_shown_on_page()"
});
formatter.result({
  "duration": 5278523400,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.close_the_AlchemyBrowser()"
});
formatter.result({
  "duration": 2196093300,
  "status": "passed"
});
formatter.uri("AlchemyJobs_PostingJobs.feature");
formatter.feature({
  "line": 2,
  "name": "Posting a job using parameterization",
  "description": "",
  "id": "posting-a-job-using-parameterization",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@AlchemyJobs"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "Post a job using details passed from the Feature file",
  "description": "",
  "id": "posting-a-job-using-parameterization;post-a-job-using-details-passed-from-the-feature-file",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "User is on AlchemyJobUrl Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "Go to Post a Job page",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Enter the Email \"mathura11@gmail.com\"",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Enter the JobTitle \"Test Title\"",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Enter the JobDescription \"Test Description\"",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Enter the ApplicationUrl \"https://alchemy.hguy.co/jobs/post-a-job/\"",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "Enter the CompanyName \"IBM\"",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "Click submit",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "Go to the Jobs page",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "Confirm job listing is shown on page.",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "Close the AlchemyBrowser",
  "keyword": "Then "
});
formatter.match({
  "location": "AlchemyJobsSteps.user_is_on_AlchemyJobUrl_Login_Page()"
});
formatter.result({
  "duration": 6826600900,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.go_to_Post_a_Job_page()"
});
formatter.result({
  "duration": 2497140900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "mathura11@gmail.com",
      "offset": 17
    }
  ],
  "location": "AlchemyJobsSteps.enter_the_Email(String)"
});
formatter.result({
  "duration": 159696500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Test Title",
      "offset": 20
    }
  ],
  "location": "AlchemyJobsSteps.enter_the_JobTitle(String)"
});
formatter.result({
  "duration": 62801800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Test Description",
      "offset": 26
    }
  ],
  "location": "AlchemyJobsSteps.enter_the_JobDescription(String)"
});
formatter.result({
  "duration": 5214184400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "https://alchemy.hguy.co/jobs/post-a-job/",
      "offset": 26
    }
  ],
  "location": "AlchemyJobsSteps.enter_the_ApplicationUrl(String)"
});
formatter.result({
  "duration": 163526400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "IBM",
      "offset": 23
    }
  ],
  "location": "AlchemyJobsSteps.enter_the_CompanyName(String)"
});
formatter.result({
  "duration": 50838600,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.click_submit()"
});
formatter.result({
  "duration": 1953325500,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.go_to_the_Jobs_page()"
});
formatter.result({
  "duration": 4809531300,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.confirm_job_listing_is_shown_on_page()"
});
formatter.result({
  "duration": 5297776400,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.close_the_AlchemyBrowser()"
});
formatter.result({
  "duration": 1906573300,
  "status": "passed"
});
formatter.uri("AlchemyJobs_SearchingJobs.feature");
formatter.feature({
  "line": 2,
  "name": "Searching for jobs using XPath",
  "description": "",
  "id": "searching-for-jobs-using-xpath",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@AlchemyJobs"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "Searching for jobs and applying to them using XPath",
  "description": "",
  "id": "searching-for-jobs-using-xpath;searching-for-jobs-and-applying-to-them-using-xpath",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "User is on AlchemyJobUrl Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "navigate to Jobs page",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Find the Keywords search input field and Type in keywords to search for jobs",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Find the filter using XPath and filter job type to show only Full Time jobs",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Find the title of the job listing and print and Click on the Apply",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "Close the AlchemyBrowser",
  "keyword": "Then "
});
formatter.match({
  "location": "AlchemyJobsSteps.user_is_on_AlchemyJobUrl_Login_Page()"
});
formatter.result({
  "duration": 6691869000,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.navigate_to_Jobs_page()"
});
formatter.result({
  "duration": 4790718200,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.find_the_Keywords_search_input_field()"
});
formatter.result({
  "duration": 67343500,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.find_the_filter_using_XPath_and_filter_job_type_to_show_only_Full_Time_jobs()"
});
formatter.result({
  "duration": 5057228900,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.find_the_title_of_the_job_listing_using_XPath_and_print_it_to_the_console()"
});
formatter.result({
  "duration": 791122900,
  "status": "passed"
});
formatter.match({
  "location": "AlchemyJobsSteps.close_the_AlchemyBrowser()"
});
formatter.result({
  "duration": 1905028200,
  "status": "passed"
});
});